import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hackday/pages/home/home_page.dart';
import 'package:hackday/pages/home/home_presenter.dart';

class PassCodePage extends StatefulWidget {
  const PassCodePage({Key? key}) : super(key: key);

  static const route = '/pass-code';

  @override
  State<PassCodePage> createState() => _PassCodePageState();
}

class _PassCodePageState extends State<PassCodePage> {
  late TextEditingController controller;
  @override
  void initState() {
    controller = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    final presenter = Get.find<IHomePresenter>();

    return Scaffold(
      backgroundColor: Colors.white,
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: presenter.getUserBbyId(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasData) {
            final Map<String, dynamic>? user = snapshot.data!.data();

            if (user?['pass_code'] == null) {
              Center(
                child: Form(
                  key: formKey,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextFormField(
                          decoration: const InputDecoration(
                              hintText: 'Choose a passcode'),
                          onChanged: (value) {
                            controller.text = value;
                          },
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required field';
                            } else if (value.length < 5) {
                              return 'Min 5 char';
                            }
                            return null;
                          },
                        ),
                        TextButton(
                          onPressed: () async {
                            if (formKey.currentState!.validate()) {
                              await presenter.syncPassCode(controller.text);
                              Get.offAllNamed('/home');
                            }
                            // Get.offAllNamed('/home');
                          },
                          child: const Text('Submit'),
                        )
                      ],
                    ),
                  ),
                ),
              );
            }

            return HomePage(user: user);
          }
          return const SizedBox();
        },
      ),
    );
  }
}
