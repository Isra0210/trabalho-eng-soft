import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:hackday/pages/login/login_presenter.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  static const route = '/login';

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    final presenter = Get.find<ILoginPresenter>();
    return Scaffold(
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Expanded(
                  child: Obx(() {
                    return presenter.loading
                        ? const Center(
                            child: CircularProgressIndicator(),
                          )
                        : ElevatedButton.icon(
                            icon: const FaIcon(
                              FontAwesomeIcons.google,
                              color: Colors.black,
                            ),
                            style: ElevatedButton.styleFrom(
                              elevation: 2,
                              minimumSize: const Size(double.infinity, 50),
                            ),
                            onPressed: () async {
                              if (FirebaseAuth.instance.currentUser != null) {
                                () => Get.offNamed('/pass-code');
                              } else {
                                await presenter.signInWithGoogle();
                              }
                            },
                            label: const Text(
                              "Google",
                              style:
                                  TextStyle(fontSize: 23, color: Colors.black),
                            ),
                          );
                  }),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
