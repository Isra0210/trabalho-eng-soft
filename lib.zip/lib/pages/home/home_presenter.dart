import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

abstract class IHomePresenter {
  Future<void> syncPassCode(String passCode);
  
  Future<DocumentSnapshot<Map<String, dynamic>>> getUserBbyId();
  
  User? get user;
}
