import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geocode/geocode.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:hackday/pages/home/home_presenter.dart';

class HomePage extends StatefulWidget {
  const HomePage({this.user, Key? key}) : super(key: key);

  final Map<String, dynamic>? user;

  static const route = '/home';

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late List<Placemark> placemarks;
  final GeoCode geoCode = GeoCode();
  late Position position;

  void getLocation() async {
    position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
  }

  @override
  void initState() {
    getLocation();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final presenter = Get.find<IHomePresenter>();

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          future: presenter.getUserBbyId(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasData) {
              final user = snapshot.data!.data();
              return ListTile(
                onTap: () async {
                  getLocation();
                },
                leading: CircleAvatar(
                  backgroundImage: NetworkImage(user!['img']),
                  backgroundColor: Colors.white,
                ),
                title: Text(user['name'].toString()),
                subtitle: FutureBuilder<Address?>(
                  future: geoCode.reverseGeocoding(
                      latitude: position.latitude, longitude: position.longitude),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Text('loading');
                    }
                    if (snapshot.hasData) {
                      return Text(snapshot.data!.city.toString());
                    }
                    // return const SizedBox();

                    return const Text('Error to get your location');
                  },
                ),
              );
            }
            return const SizedBox();
          },
        ),
      ),
    );
  }
}
