import 'package:get/get.dart';
import 'package:hackday/pages/home/home_presenter.dart';
import 'package:hackday/presenters/home/getx_home_presenter.dart';

class HomeBinding implements Bindings {
  @override
  void dependencies() {
    Get.put<IHomePresenter>(GetXHomePresenter());
  }
}