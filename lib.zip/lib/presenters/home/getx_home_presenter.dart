import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

import '../../pages/home/home_presenter.dart';

class GetXHomePresenter extends GetxController implements IHomePresenter {
  @override
  User? get user => FirebaseAuth.instance.currentUser;

  @override
  Future<void> syncPassCode(String passCode) async {
    final user = FirebaseAuth.instance.currentUser!;
    FirebaseFirestore.instance.collection('users').doc(user.uid).set(
      {'pass_code': passCode},
      SetOptions(merge: true),
    );
  }
  
  @override
  Future<DocumentSnapshot<Map<String, dynamic>>> getUserBbyId() async {
    final user = FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid);    
    
    return user.get();
  }
}
