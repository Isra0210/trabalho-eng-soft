import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hackday/pages/login/login_page.dart';
import 'package:hackday/pages/pass_code.dart/pass_code_page.dart';
import 'package:hackday/presenters/home/home_binding.dart';
import 'package:hackday/presenters/login/login_binding.dart';
//ignore: depend_on_referenced_packages
import 'package:geolocator_android/geolocator_android.dart';
//ignore: depend_on_referenced_packages
import 'package:geolocator_apple/geolocator_apple.dart';

import 'pages/home/home_page.dart';

void _registerPlatformInstance() {
    if (Platform.isAndroid) {
      GeolocatorAndroid.registerWith();
    } else if (Platform.isIOS) {
      GeolocatorApple.registerWith();
    }
}

void main() async {
  _registerPlatformInstance();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter project',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: user == null ? '/login' : '/pass-code',
      getPages: [
        GetPage(
          binding: LoginBinding(),
          name: '/login',
          page: () => const LoginPage(),
        ),
        GetPage(
          binding: HomeBinding(),
          name: '/home',
          page: () => const HomePage(),
        ),
        GetPage(
          bindings: [
            LoginBinding(),
            HomeBinding(),
          ],
          name: '/pass-code',
          page: () => const PassCodePage(),
        )
      ],
    );
  }
}
